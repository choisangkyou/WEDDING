-- MySQL dump 10.13  Distrib 5.6.24, for Win32 (x86)
--
-- Host: localhost    Database: wowwedding
-- ------------------------------------------------------
-- Server version	5.7.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `partner`
--

DROP TABLE IF EXISTS `partner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partner` (
  `p_Idx` int(11) NOT NULL AUTO_INCREMENT COMMENT '업체 일련번호',
  `m_Idx` int(11) NOT NULL COMMENT '회원일련번호',
  `p_Name` varchar(45) NOT NULL COMMENT '업체명',
  `p_Category` varchar(10) NOT NULL COMMENT '분류(분류코드 테이블 참조)',
  `p_Phone` varchar(13) NOT NULL COMMENT '전화',
  `p_Address` varchar(99) NOT NULL COMMENT '주소',
  `p_Intorduce` text NOT NULL COMMENT '업체 소개',
  `p_Operation` varchar(10) NOT NULL COMMENT '운영방식 (별도 테이블 참조)',
  `p_Price` int(11) NOT NULL COMMENT '가격(원)',
  `p_Photo1` varchar(99) NOT NULL COMMENT '사진1(대표이미지)',
  `p_Photo2` varchar(99) DEFAULT NULL,
  `p_Photo3` varchar(99) DEFAULT NULL,
  `p_Photo4` varchar(99) DEFAULT NULL,
  PRIMARY KEY (`p_Idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='파트너 ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partner`
--

LOCK TABLES `partner` WRITE;
/*!40000 ALTER TABLE `partner` DISABLE KEYS */;
/*!40000 ALTER TABLE `partner` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-04-03 17:22:59
